import signal
import sys
from robot.core.robot_controller import RobotController
from robot.utils.config import SUCCESS_MESSAGES, ERROR_MESSAGES

def signal_handler(sig, frame):
    """Handle shutdown signals"""
    print("\nShutting down robot systems...")
    if robot_controller:
        robot_controller.stop()
    print(SUCCESS_MESSAGES['shutdown'])
    sys.exit(0)

def main():
    try:
        # Initialize robot controller
        global robot_controller
        robot_controller = RobotController()
        
        # Register signal handlers
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Start robot systems
        robot_controller.start()
        print(SUCCESS_MESSAGES['startup'])
        
        # Keep main thread alive
        signal.pause()
        
    except Exception as e:
        print(f"Fatal error: {e}")
        if robot_controller:
            robot_controller.emergency_stop_triggered()
        sys.exit(1)

if __name__ == "__main__":
    robot_controller = None
    main()
