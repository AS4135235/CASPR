# Camera settings
CAMERA_RESOLUTION = {
    'width': 640,
    'height': 480
}

# Movement settings
MOVEMENT_SPEEDS = {
    'slow': 0.3,
    'normal': 0.6,
    'fast': 1.0
}

# Audio settings
AUDIO_CONFIG = {
    'sample_rate': 44100,
    'channels': 1,
    'chunk_size': 1024,
    'format': 'float32'
}

# Vision settings
VISION_CONFIG = {
    'face_detection_confidence': 0.8,
    'object_detection_confidence': 0.6,
    'motion_detection_threshold': 20
}

# Security settings
SECURITY_CONFIG = {
    'auth_token_expiry': 24,  # hours
    'voice_verification_threshold': 0.8,
    'network_scan_interval': 300,  # seconds
    'suspicious_activity_threshold': 100
}

# Hardware settings
HARDWARE_CONFIG = {
    'servo_frequency': 50,
    'led_pwm_frequency': 100,
    'gpio_mode': 'BCM'
}

# Robot behavior settings
BEHAVIOR_CONFIG = {
    'idle_scan_interval': 30,  # seconds
    'max_tracking_duration': 300,  # seconds
    'min_approach_distance': 0.5,  # meters
    'max_speed': 0.8  # relative speed (0-1)
}

# Error messages
ERROR_MESSAGES = {
    'hardware_error': 'Hardware initialization failed',
    'camera_error': 'Camera initialization failed',
    'audio_error': 'Audio initialization failed',
    'network_error': 'Network monitoring failed',
    'auth_error': 'Authentication failed'
}

# Success messages
SUCCESS_MESSAGES = {
    'startup': 'Robot systems initialized successfully',
    'shutdown': 'Robot systems shut down successfully',
    'command_executed': 'Command executed successfully'
}
