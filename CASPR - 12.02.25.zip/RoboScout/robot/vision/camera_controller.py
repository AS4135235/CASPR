import cv2
import numpy as np
import threading
import time
import warnings
from ..utils.config import CAMERA_RESOLUTION

class CameraController:
    def __init__(self):
        self.camera = None
        self.is_running = False
        self.is_available = True  # Flag to track if camera is available
        self.current_frame = None
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.object_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_fullbody.xml')
        self.frame_lock = threading.Lock()
        self.last_motion = None

    def start_monitoring(self):
        """Start camera monitoring in a separate thread"""
        try:
            self.camera = cv2.VideoCapture(0)
            if not self.camera.isOpened():
                raise RuntimeError("Failed to open camera")

            self.camera.set(3, CAMERA_RESOLUTION['width'])
            self.camera.set(4, CAMERA_RESOLUTION['height'])
            self.is_running = True
            self.is_available = True

            self.processing_thread = threading.Thread(target=self._process_frames)
            self.processing_thread.daemon = True
            self.processing_thread.start()

        except Exception as e:
            self.is_available = False
            warnings.warn(f"Camera monitoring disabled: {str(e)}")
            self.stop()

    def stop(self):
        """Stop camera monitoring"""
        self.is_running = False
        if self.camera and self.is_available:
            try:
                self.camera.release()
            except Exception as e:
                warnings.warn(f"Error releasing camera: {str(e)}")

    def _process_frames(self):
        """Main frame processing loop"""
        prev_frame = None

        while self.is_running and self.is_available:
            try:
                ret, frame = self.camera.read()
                if not ret:
                    warnings.warn("Failed to read frame from camera")
                    continue

                # Motion detection
                if prev_frame is not None:
                    motion = self._detect_motion(prev_frame, frame)
                    if motion:
                        self.last_motion = {
                            'timestamp': time.time(),
                            'location': motion
                        }

                # Face detection
                faces = self._detect_faces(frame)

                # Object detection
                objects = self._detect_objects(frame)

                with self.frame_lock:
                    self.current_frame = {
                        'frame': frame,
                        'faces': faces,
                        'objects': objects,
                        'motion': self.last_motion
                    }

                prev_frame = frame.copy()
                time.sleep(0.03)  # ~30 FPS

            except Exception as e:
                warnings.warn(f"Error processing camera frame: {str(e)}")
                time.sleep(0.1)

    def _detect_motion(self, prev_frame, curr_frame):
        """Detect motion between frames"""
        try:
            diff = cv2.absdiff(prev_frame, curr_frame)
            gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
            blur = cv2.GaussianBlur(gray, (5, 5), 0)
            _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
            dilated = cv2.dilate(thresh, None, iterations=3)
            contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            significant_motion = []
            for contour in contours:
                if cv2.contourArea(contour) > 1000:  # Adjust threshold as needed
                    (x, y, w, h) = cv2.boundingRect(contour)
                    significant_motion.append((x, y, w, h))

            return significant_motion if significant_motion else None

        except Exception as e:
            warnings.warn(f"Error in motion detection: {str(e)}")
            return None

    def _detect_faces(self, frame):
        """Detect faces in frame"""
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )
            return faces
        except Exception as e:
            warnings.warn(f"Error in face detection: {str(e)}")
            return []

    def _detect_objects(self, frame):
        """Detect objects in frame"""
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            objects = self.object_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )
            return objects
        except Exception as e:
            warnings.warn(f"Error in object detection: {str(e)}")
            return []

    def get_latest_data(self):
        """Get the latest processed frame data"""
        if not self.is_available:
            return {'status': 'camera_disabled', 'reason': 'Camera not available'}

        with self.frame_lock:
            return self.current_frame if self.current_frame else None