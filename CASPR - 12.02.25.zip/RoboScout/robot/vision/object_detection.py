import tensorflow as tf
import numpy as np
import cv2

class ObjectDetector:
    def __init__(self):
        # Load pre-trained model (using MobileNetV2 for efficiency on Raspberry Pi)
        self.model = tf.keras.applications.MobileNetV2(
            weights='imagenet',
            include_top=True
        )
        self.img_size = (224, 224)  # MobileNetV2 input size
        
        # Load class labels
        with open('imagenet_classes.txt', 'r') as f:
            self.class_labels = [line.strip() for line in f.readlines()]

    def preprocess_image(self, image):
        """Preprocess image for model input"""
        image = cv2.resize(image, self.img_size)
        image = tf.keras.applications.mobilenet_v2.preprocess_input(image)
        return image

    def detect_objects(self, frame):
        """Detect objects in the given frame"""
        try:
            # Preprocess the image
            processed_image = self.preprocess_image(frame)
            input_tensor = np.expand_dims(processed_image, axis=0)

            # Make prediction
            predictions = self.model.predict(input_tensor)
            results = tf.keras.applications.mobilenet_v2.decode_predictions(predictions, top=3)[0]

            detected_objects = []
            for (_, label, confidence) in results:
                if confidence > 0.5:  # Confidence threshold
                    detected_objects.append({
                        'label': label,
                        'confidence': float(confidence)
                    })

            return detected_objects

        except Exception as e:
            print(f"Error in object detection: {e}")
            return []

    def get_object_location(self, frame, object_name):
        """Find specific object in frame and return its location"""
        objects = self.detect_objects(frame)
        for obj in objects:
            if object_name.lower() in obj['label'].lower():
                # Implement basic object localization here
                # This is a simplified version - you might want to use
                # more sophisticated object detection models for precise location
                height, width = frame.shape[:2]
                return {
                    'x': width // 2,  # Center of frame as approximation
                    'y': height // 2,
                    'confidence': obj['confidence']
                }
        return None

