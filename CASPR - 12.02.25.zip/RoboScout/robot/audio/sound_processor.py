import pyaudio
import numpy as np
import wave
import threading
import time
from collections import deque
import warnings

class SoundProcessor:
    def __init__(self):
        self.CHUNK = 1024
        self.FORMAT = pyaudio.paFloat32
        self.CHANNELS = 1
        self.RATE = 44100
        self.THRESHOLD = 0.1  # Adjust for sound detection sensitivity

        self.p = pyaudio.PyAudio()
        self.stream = None
        self.is_running = False
        self.is_available = True  # Flag to track if audio processing is available

        self.audio_buffer = deque(maxlen=50)  # ~1 second of audio
        self.latest_data = None
        self.lock = threading.Lock()

    def start_listening(self):
        """Start audio processing if hardware is available"""
        try:
            # Try to open the audio stream
            self.stream = self.p.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                frames_per_buffer=self.CHUNK
            )

            self.is_running = True
            self._process_audio()
        except OSError as e:
            self.is_available = False
            warnings.warn(f"Audio processing disabled: {str(e)}")
            self.stop()  # Clean up any partially initialized resources
        except Exception as e:
            warnings.warn(f"Unexpected error in audio initialization: {str(e)}")
            self.is_available = False
            self.stop()

    def stop(self):
        """Stop audio processing"""
        self.is_running = False
        if self.stream:
            try:
                self.stream.stop_stream()
                self.stream.close()
            except Exception as e:
                warnings.warn(f"Error closing audio stream: {str(e)}")
        if self.p:
            try:
                self.p.terminate()
            except Exception as e:
                warnings.warn(f"Error terminating PyAudio: {str(e)}")

    def _process_audio(self):
        """Main audio processing loop"""
        while self.is_running and self.is_available:
            try:
                data = self.stream.read(self.CHUNK, exception_on_overflow=False)
                audio_data = np.frombuffer(data, dtype=np.float32)

                # Calculate audio features
                rms = np.sqrt(np.mean(np.square(audio_data)))
                frequency = self._estimate_frequency(audio_data)

                # Detect significant sounds
                if rms > self.THRESHOLD:
                    sound_type = self._classify_sound(rms, frequency)

                    with self.lock:
                        self.latest_data = {
                            'timestamp': time.time(),
                            'rms': rms,
                            'frequency': frequency,
                            'sound_type': sound_type
                        }

                # Store raw audio data
                self.audio_buffer.append(audio_data)

            except Exception as e:
                warnings.warn(f"Error processing audio: {str(e)}")
                time.sleep(0.1)

    def _estimate_frequency(self, audio_data):
        """Estimate the dominant frequency in the audio signal"""
        try:
            fft_data = np.fft.fft(audio_data)
            freqs = np.fft.fftfreq(len(fft_data), 1.0/self.RATE)

            # Get positive frequencies only
            positive_freqs = freqs[:len(freqs)//2]
            magnitudes = np.abs(fft_data[:len(freqs)//2])

            # Find the peak frequency
            peak_frequency = positive_freqs[np.argmax(magnitudes)]
            return abs(peak_frequency)

        except Exception as e:
            warnings.warn(f"Error in frequency estimation: {str(e)}")
            return 0

    def _classify_sound(self, rms, frequency):
        """Classify the type of sound based on its characteristics"""
        if frequency < 100:
            return 'low_frequency_noise'
        elif frequency < 1000:
            if rms > self.THRESHOLD * 2:
                return 'bang'
            return 'speech'
        elif frequency < 4000:
            return 'high_pitch'
        else:
            return 'ultrasonic'

    def get_latest_data(self):
        """Get the latest processed audio data"""
        if not self.is_available:
            return {'status': 'audio_disabled', 'reason': 'No audio device available'}

        with self.lock:
            return self.latest_data

    def save_audio_snippet(self, filename, duration=1.0):
        """Save a short audio snippet to file"""
        if not self.is_available:
            warnings.warn("Cannot save audio: Audio processing is disabled")
            return False

        frames = list(self.audio_buffer)[-int(duration * self.RATE / self.CHUNK):]

        if frames:
            try:
                with wave.open(filename, 'wb') as wf:
                    wf.setnchannels(self.CHANNELS)
                    wf.setsampwidth(self.p.get_sample_size(self.FORMAT))
                    wf.setframerate(self.RATE)
                    wf.writeframes(b''.join(frames))
                return True
            except Exception as e:
                warnings.warn(f"Error saving audio snippet: {str(e)}")
                return False
        return False