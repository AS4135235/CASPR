import speech_recognition as sr
import numpy as np
from scipy.io import wavfile
import threading
import queue

class VoiceRecognition:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.command_queue = queue.Queue()
        self.is_running = False
        self.voice_patterns = {}  # Store voice signatures for authentication
        
    def start_recognition(self):
        """Start voice recognition in a separate thread"""
        self.is_running = True
        self.recognition_thread = threading.Thread(target=self._recognition_loop)
        self.recognition_thread.daemon = True
        self.recognition_thread.start()

    def stop_recognition(self):
        """Stop voice recognition"""
        self.is_running = False

    def _recognition_loop(self):
        """Main voice recognition loop"""
        with sr.Microphone() as source:
            self.recognizer.adjust_for_ambient_noise(source)
            
            while self.is_running:
                try:
                    audio = self.recognizer.listen(source, timeout=1)
                    
                    # Get voice signature for authentication
                    voice_signature = self._extract_voice_signature(audio)
                    
                    # Attempt to recognize speech
                    text = self.recognizer.recognize_google(audio)
                    
                    command = self._parse_command(text)
                    if command:
                        self.command_queue.put({
                            'command': command,
                            'voice_signature': voice_signature,
                            'raw_text': text
                        })
                
                except sr.WaitTimeoutError:
                    continue
                except sr.UnknownValueError:
                    continue
                except Exception as e:
                    print(f"Error in voice recognition: {e}")

    def _extract_voice_signature(self, audio):
        """Extract unique voice characteristics for authentication"""
        try:
            # Convert audio data to numpy array
            audio_data = np.frombuffer(audio.frame_data, dtype=np.int16)
            
            # Extract basic voice features
            features = {
                'average_energy': np.mean(np.abs(audio_data)),
                'zero_crossing_rate': np.sum(np.diff(np.signbit(audio_data))),
                'spectral_centroid': self._compute_spectral_centroid(audio_data),
                'pitch': self._estimate_pitch(audio_data)
            }
            
            return features
            
        except Exception as e:
            print(f"Error extracting voice signature: {e}")
            return None

    def _compute_spectral_centroid(self, audio_data):
        """Compute the spectral centroid of the audio signal"""
        spectrum = np.fft.fft(audio_data)
        frequencies = np.fft.fftfreq(len(spectrum))
        magnitudes = np.abs(spectrum)
        return np.sum(frequencies * magnitudes) / np.sum(magnitudes)

    def _estimate_pitch(self, audio_data):
        """Estimate the fundamental frequency (pitch) of the voice"""
        correlations = np.correlate(audio_data, audio_data, mode='full')
        correlations = correlations[len(correlations)//2:]
        peak_index = np.argmax(correlations)
        return peak_index

    def _parse_command(self, text):
        """Parse recognized text into commands"""
        text = text.lower()
        
        # Basic command mapping
        command_mapping = {
            'stop': 'stop',
            'move forward': 'move_forward',
            'move backward': 'move_backward',
            'turn left': 'turn_left',
            'turn right': 'turn_right',
            'look at me': 'face_user',
            'scan network': 'scan_network',
            'emergency stop': 'emergency_stop'
        }
        
        for phrase, command in command_mapping.items():
            if phrase in text:
                return command
                
        return None

    def register_voice(self, user_id, audio_sample):
        """Register a new voice pattern for authentication"""
        voice_signature = self._extract_voice_signature(audio_sample)
        if voice_signature:
            self.voice_patterns[user_id] = voice_signature
            return True
        return False

    def verify_voice(self, voice_signature, threshold=0.8):
        """Verify if a voice signature matches any registered users"""
        if not voice_signature:
            return False
            
        for user_id, stored_signature in self.voice_patterns.items():
            similarity = self._compare_signatures(voice_signature, stored_signature)
            if similarity > threshold:
                return user_id
        return None

    def _compare_signatures(self, sig1, sig2):
        """Compare two voice signatures and return similarity score"""
        try:
            features = ['average_energy', 'zero_crossing_rate', 
                       'spectral_centroid', 'pitch']
            
            differences = []
            for feature in features:
                diff = abs(sig1[feature] - sig2[feature])
                normalized_diff = 1 - (diff / max(sig1[feature], sig2[feature]))
                differences.append(normalized_diff)
                
            return np.mean(differences)
            
        except Exception as e:
            print(f"Error comparing signatures: {e}")
            return 0

