import RPi.GPIO as GPIO
import time

class MovementController:
    def __init__(self):
        # GPIO pins for left track
        self.LEFT_FORWARD = 17
        self.LEFT_BACKWARD = 18
        # GPIO pins for right track
        self.RIGHT_FORWARD = 22
        self.RIGHT_BACKWARD = 23
        
        self.setup_gpio()
        self.current_speed = 0
        self.is_moving = False

    def setup_gpio(self):
        """Initialize GPIO pins"""
        GPIO.setmode(GPIO.BCM)
        pins = [self.LEFT_FORWARD, self.LEFT_BACKWARD,
                self.RIGHT_FORWARD, self.RIGHT_BACKWARD]
        
        for pin in pins:
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)

    def move_forward(self, speed=1.0):
        """Move robot forward"""
        GPIO.output(self.LEFT_FORWARD, GPIO.HIGH)
        GPIO.output(self.RIGHT_FORWARD, GPIO.HIGH)
        GPIO.output(self.LEFT_BACKWARD, GPIO.LOW)
        GPIO.output(self.RIGHT_BACKWARD, GPIO.LOW)
        self.current_speed = speed
        self.is_moving = True

    def move_backward(self, speed=1.0):
        """Move robot backward"""
        GPIO.output(self.LEFT_BACKWARD, GPIO.HIGH)
        GPIO.output(self.RIGHT_BACKWARD, GPIO.HIGH)
        GPIO.output(self.LEFT_FORWARD, GPIO.LOW)
        GPIO.output(self.RIGHT_FORWARD, GPIO.LOW)
        self.current_speed = speed
        self.is_moving = True

    def turn_left(self, speed=0.5):
        """Turn robot left"""
        GPIO.output(self.RIGHT_FORWARD, GPIO.HIGH)
        GPIO.output(self.LEFT_BACKWARD, GPIO.HIGH)
        GPIO.output(self.LEFT_FORWARD, GPIO.LOW)
        GPIO.output(self.RIGHT_BACKWARD, GPIO.LOW)
        self.current_speed = speed
        self.is_moving = True

    def turn_right(self, speed=0.5):
        """Turn robot right"""
        GPIO.output(self.LEFT_FORWARD, GPIO.HIGH)
        GPIO.output(self.RIGHT_BACKWARD, GPIO.HIGH)
        GPIO.output(self.RIGHT_FORWARD, GPIO.LOW)
        GPIO.output(self.LEFT_BACKWARD, GPIO.LOW)
        self.current_speed = speed
        self.is_moving = True

    def stop(self):
        """Stop all movement"""
        pins = [self.LEFT_FORWARD, self.LEFT_BACKWARD,
                self.RIGHT_FORWARD, self.RIGHT_BACKWARD]
        for pin in pins:
            GPIO.output(pin, GPIO.LOW)
        self.current_speed = 0
        self.is_moving = False

    def cleanup(self):
        """Clean up GPIO"""
        self.stop()
        GPIO.cleanup()

