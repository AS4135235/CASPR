import time
import threading
from ..hardware.servo_controller import ServoController
from ..hardware.led_controller import LEDController
from ..vision.camera_controller import CameraController
from ..audio.sound_processor import SoundProcessor
from ..security.network_monitor import NetworkMonitor
from ..security.auth import AuthenticationSystem
import warnings

class RobotController:
    def __init__(self):
        self.servo_controller = ServoController()
        self.led_controller = LEDController()
        self.camera_controller = CameraController()
        self.sound_processor = SoundProcessor()
        self.network_monitor = NetworkMonitor()
        self.auth_system = AuthenticationSystem()

        self.is_running = False
        self.emergency_stop = False
        self.subsystem_status = {}

    def start(self):
        """Initialize and start all robot systems"""
        self.is_running = True
        self.subsystem_status = {}

        # Start all subsystems in separate threads
        threads = []

        # Camera subsystem
        try:
            threads.append(threading.Thread(target=self.camera_controller.start_monitoring))
            self.subsystem_status['camera'] = 'starting'
        except Exception as e:
            self.subsystem_status['camera'] = f'disabled: {str(e)}'
            warnings.warn(f"Failed to initialize camera subsystem: {e}")

        # Audio subsystem
        try:
            threads.append(threading.Thread(target=self.sound_processor.start_listening))
            self.subsystem_status['audio'] = 'starting'
        except Exception as e:
            self.subsystem_status['audio'] = f'disabled: {str(e)}'
            warnings.warn(f"Failed to initialize audio subsystem: {e}")

        # Network monitoring
        try:
            threads.append(threading.Thread(target=self.network_monitor.start_monitoring))
            self.subsystem_status['network'] = 'starting'
        except Exception as e:
            self.subsystem_status['network'] = f'disabled: {str(e)}'
            warnings.warn(f"Failed to initialize network monitoring: {e}")

        # Main control loop
        threads.append(threading.Thread(target=self._main_control_loop))

        for thread in threads:
            thread.daemon = True
            thread.start()

        # Update status after initialization
        if hasattr(self.camera_controller, 'is_available'):
            self.subsystem_status['camera'] = 'running' if self.camera_controller.is_available else 'disabled'
        if hasattr(self.sound_processor, 'is_available'):
            self.subsystem_status['audio'] = 'running' if self.sound_processor.is_available else 'disabled'
        if hasattr(self.network_monitor, 'bluetooth_available'):
            self.subsystem_status['bluetooth'] = 'running' if self.network_monitor.bluetooth_available else 'disabled'

        print("Robot systems initialized successfully")
        self._log_subsystem_status()

    def stop(self):
        """Gracefully stop all robot systems"""
        self.is_running = False
        self.servo_controller.stop()
        self.led_controller.stop()
        self.camera_controller.stop()
        self.sound_processor.stop()
        self.network_monitor.stop()

    def emergency_stop_triggered(self):
        """Handle emergency stop"""
        self.emergency_stop = True
        self.stop()
        self.led_controller.set_emergency_mode()

    def _main_control_loop(self):
        """Main robot control loop"""
        while self.is_running and not self.emergency_stop:
            try:
                # Process vision data
                vision_data = self.camera_controller.get_latest_data()
                if vision_data and vision_data.get('status') != 'camera_disabled':
                    motion_detected = vision_data.get('motion')
                    if motion_detected:
                        self.handle_motion_detection(vision_data)

                # Process audio data
                audio_data = self.sound_processor.get_latest_data()
                if audio_data and audio_data.get('status') != 'audio_disabled':
                    command_detected = audio_data.get('sound_type') == 'speech'
                    if command_detected:
                        self.handle_voice_command(audio_data)

                # Process network security data
                security_data = self.network_monitor.get_latest_data()
                if security_data and security_data.get('suspicious_activity'):
                    self.handle_security_threat(security_data)

                time.sleep(0.1)  # Prevent CPU overuse

            except Exception as e:
                warnings.warn(f"Error in main control loop: {e}")
                self.led_controller.set_error_mode()

    def _log_subsystem_status(self):
        """Log the status of all subsystems"""
        print("\nSubsystem Status:")
        for system, status in self.subsystem_status.items():
            print(f"- {system}: {status}")

    def handle_motion_detection(self, data):
        """Handle detected motion"""
        if data is None or data.get('status') == 'camera_disabled':
            return

        motion = data.get('motion', [])
        faces = data.get('faces', [])
        if len(faces) > 0 or len(motion) > 0:
            self.led_controller.set_attention_mode()
            # Calculate direction based on the first detected face or motion
            if len(faces) > 0:
                x, y, w, h = faces[0]
            else:
                x, y, w, h = motion[0]

            frame_width = data.get('frame', {}).get('shape', (0, 640))[1]
            direction = (90 + (x + w/2 - frame_width/2) * 0.1, 90)  # Basic horizontal tracking
            self.servo_controller.face_direction(direction)

    def handle_voice_command(self, data):
        """Process voice commands"""
        if data is None or data.get('status') == 'audio_disabled':
            return

        voice_pattern = data.get('voice_signature')
        if voice_pattern and self.auth_system.verify_voice('default_user', voice_pattern)[0]:
            sound_type = data.get('sound_type')
            if sound_type == 'speech':
                if 'stop' in str(data.get('frequency', '')):  # Simple frequency-based detection
                    self.stop()
                elif 'follow' in str(data.get('frequency', '')):
                    self.servo_controller.enable_tracking_mode()

    def handle_security_threat(self, data):
        """Handle detected security threats"""
        if data is None:
            return

        self.led_controller.set_alert_mode()
        threats = data.get('suspicious_activity', [])
        if threats:
            for threat in threats:
                print(f"Security threat detected: {threat.get('type')} - {threat.get('details')}")

    def get_system_status(self):
        """Get the current status of all subsystems"""
        return self.subsystem_status