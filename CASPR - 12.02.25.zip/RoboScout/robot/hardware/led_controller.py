import time
import threading
import os

# Use mock GPIO for development, real GPIO on Raspberry Pi
try:
    import RPi.GPIO as GPIO
except ImportError:
    from .mock_gpio import GPIO

class LEDController:
    def __init__(self):
        # GPIO pins for RGB LED
        self.RED_PIN = 27
        self.GREEN_PIN = 22
        self.BLUE_PIN = 17

        # Current LED state
        self.current_mode = 'normal'
        self.is_running = False
        self.animation_thread = None

        self.setup_gpio()

    def setup_gpio(self):
        """Initialize GPIO for LED control"""
        GPIO.setmode(GPIO.BCM)

        # Setup RGB LED pins
        for pin in [self.RED_PIN, self.GREEN_PIN, self.BLUE_PIN]:
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)

        # Setup PWM for smooth transitions
        self.red_pwm = GPIO.PWM(self.RED_PIN, 100)
        self.green_pwm = GPIO.PWM(self.GREEN_PIN, 100)
        self.blue_pwm = GPIO.PWM(self.BLUE_PIN, 100)

        # Start PWM with 0% duty cycle
        self.red_pwm.start(0)
        self.green_pwm.start(0)
        self.blue_pwm.start(0)

    def set_color(self, red, green, blue):
        """Set RGB LED color (values 0-100)"""
        self.red_pwm.ChangeDutyCycle(red)
        self.green_pwm.ChangeDutyCycle(green)
        self.blue_pwm.ChangeDutyCycle(blue)

    def _start_animation(self, animation_func):
        """Start LED animation in separate thread"""
        if self.animation_thread and self.animation_thread.is_alive():
            self.is_running = False
            self.animation_thread.join()

        self.is_running = True
        self.animation_thread = threading.Thread(target=animation_func)
        self.animation_thread.daemon = True
        self.animation_thread.start()

    def set_normal_mode(self):
        """Set normal operating mode (steady green)"""
        self.current_mode = 'normal'
        self.set_color(0, 100, 0)

    def set_attention_mode(self):
        """Set attention mode (yellow pulsing)"""
        self.current_mode = 'attention'
        self._start_animation(self._attention_animation)

    def set_alert_mode(self):
        """Set alert mode (steady red)"""
        self.current_mode = 'alert'
        self.set_color(100, 0, 0)

    def set_error_mode(self):
        """Set error mode (flashing red)"""
        self.current_mode = 'error'
        self._start_animation(self._error_animation)

    def set_emergency_mode(self):
        """Set emergency mode (alternating red and blue flash)"""
        self.current_mode = 'emergency'
        self._start_animation(self._emergency_animation)

    # Mood-based lighting configurations
    def set_happy_mode(self):
        """Set happy mood (bright yellow-green with gentle pulsing)"""
        self.current_mode = 'happy'
        self._start_animation(self._happy_animation)

    def set_calm_mode(self):
        """Set calm mood (soft blue with slow breathing effect)"""
        self.current_mode = 'calm'
        self._start_animation(self._calm_animation)

    def set_curious_mode(self):
        """Set curious mood (cyan with occasional brightness variations)"""
        self.current_mode = 'curious'
        self._start_animation(self._curious_animation)

    def set_sleepy_mode(self):
        """Set sleepy mood (very dim warm white, slowly pulsing)"""
        self.current_mode = 'sleepy'
        self._start_animation(self._sleepy_animation)

    def set_excited_mode(self):
        """Set excited mood (rapid cycling through bright colors when recognizing familiar faces)"""
        self.current_mode = 'excited'
        self._start_animation(self._excited_animation)

    def set_suspicious_mode(self):
        """Set suspicious mood (slow pulsing amber with red flashes)"""
        self.current_mode = 'suspicious'
        self._start_animation(self._suspicious_animation)

    def set_motivated_mode(self):
        """Set motivated/learning mood (bright white with blue pulses)"""
        self.current_mode = 'motivated'
        self._start_animation(self._motivated_animation)

    def set_angry_mode(self):
        """Set angry mood (intense red pulsing with orange)"""
        self.current_mode = 'angry'
        self._start_animation(self._angry_animation)

    def set_busy_mode(self):
        """Set busy mood (steady purple with white pulses)"""
        self.current_mode = 'busy'
        self._start_animation(self._busy_animation)

    def _excited_animation(self):
        """Rapid cycling through bright colors animation"""
        colors = [
            (100, 0, 0),    # Red
            (100, 100, 0),  # Yellow
            (0, 100, 0),    # Green
            (0, 100, 100),  # Cyan
            (0, 0, 100),    # Blue
            (100, 0, 100)   # Magenta
        ]
        while self.is_running and self.current_mode == 'excited':
            for r, g, b in colors:
                if not self.is_running:
                    break
                self.set_color(r, g, b)
                time.sleep(0.2)

    def _suspicious_animation(self):
        """Slow pulsing amber with occasional red flashes"""
        while self.is_running and self.current_mode == 'suspicious':
            # Amber pulse
            for brightness in range(0, 101, 2):
                if not self.is_running:
                    break
                self.set_color(brightness, brightness * 0.7, 0)  # Amber color
                time.sleep(0.03)

            # Quick red flash
            self.set_color(100, 0, 0)
            time.sleep(0.1)
            self.set_color(0, 0, 0)
            time.sleep(0.1)

            # Return to amber and fade out
            for brightness in range(100, -1, -2):
                if not self.is_running:
                    break
                self.set_color(brightness, brightness * 0.7, 0)
                time.sleep(0.03)

    def _motivated_animation(self):
        """Bright white with blue pulses animation"""
        while self.is_running and self.current_mode == 'motivated':
            # Bright white base
            self.set_color(80, 80, 80)
            time.sleep(0.5)

            # Blue pulse
            for brightness in range(0, 101, 5):
                if not self.is_running:
                    break
                self.set_color(80-brightness*0.3, 80-brightness*0.3, 100)
                time.sleep(0.02)
            for brightness in range(100, -1, -5):
                if not self.is_running:
                    break
                self.set_color(80-brightness*0.3, 80-brightness*0.3, 100)
                time.sleep(0.02)

    def _angry_animation(self):
        """Intense red pulsing with orange undertones"""
        while self.is_running and self.current_mode == 'angry':
            # Intense red to orange pulsing
            for brightness in range(50, 101, 5):
                if not self.is_running:
                    break
                self.set_color(100, brightness * 0.3, 0)  # Red with orange undertone
                time.sleep(0.02)
            for brightness in range(100, 49, -5):
                if not self.is_running:
                    break
                self.set_color(100, brightness * 0.3, 0)
                time.sleep(0.02)

    def _busy_animation(self):
        """Steady purple with white pulses animation"""
        while self.is_running and self.current_mode == 'busy':
            # Purple base
            self.set_color(50, 0, 50)
            time.sleep(0.5)

            # White pulse overlay
            for brightness in range(0, 51, 2):
                if not self.is_running:
                    break
                self.set_color(50 + brightness, brightness, 50 + brightness)
                time.sleep(0.03)
            for brightness in range(50, -1, -2):
                if not self.is_running:
                    break
                self.set_color(50 + brightness, brightness, 50 + brightness)
                time.sleep(0.03)


    def _attention_animation(self):
        """Yellow pulsing animation"""
        while self.is_running and self.current_mode == 'attention':
            for brightness in range(0, 101, 2):
                if not self.is_running:
                    break
                self.set_color(brightness, brightness, 0)
                time.sleep(0.02)
            for brightness in range(100, -1, -2):
                if not self.is_running:
                    break
                self.set_color(brightness, brightness, 0)
                time.sleep(0.02)

    def _error_animation(self):
        """Red flashing animation"""
        while self.is_running and self.current_mode == 'error':
            self.set_color(100, 0, 0)
            time.sleep(0.5)
            self.set_color(0, 0, 0)
            time.sleep(0.5)

    def _emergency_animation(self):
        """Alternating red and blue flash animation"""
        while self.is_running and self.current_mode == 'emergency':
            # Red flash
            self.set_color(100, 0, 0)
            time.sleep(0.2)
            self.set_color(0, 0, 0)
            time.sleep(0.1)
            # Blue flash
            self.set_color(0, 0, 100)
            time.sleep(0.2)
            self.set_color(0, 0, 0)
            time.sleep(0.1)

    def _happy_animation(self):
        """Bright yellow-green gentle pulsing"""
        while self.is_running and self.current_mode == 'happy':
            for brightness in range(60, 101, 2):
                if not self.is_running:
                    break
                self.set_color(brightness-30, brightness, 0)  # Yellow-green mix
                time.sleep(0.05)
            for brightness in range(100, 59, -2):
                if not self.is_running:
                    break
                self.set_color(brightness-30, brightness, 0)
                time.sleep(0.05)

    def _calm_animation(self):
        """Soft blue breathing effect"""
        while self.is_running and self.current_mode == 'calm':
            for brightness in range(0, 51, 1):
                if not self.is_running:
                    break
                self.set_color(0, 0, brightness)
                time.sleep(0.1)
            for brightness in range(50, -1, -1):
                if not self.is_running:
                    break
                self.set_color(0, 0, brightness)
                time.sleep(0.1)

    def _curious_animation(self):
        """Cyan with occasional brightness variations"""
        while self.is_running and self.current_mode == 'curious':
            base_brightness = 50
            for _ in range(5):  # Regular pattern
                if not self.is_running:
                    break
                self.set_color(0, base_brightness, base_brightness)
                time.sleep(0.5)
            # Occasional brightness spike
            self.set_color(0, 80, 80)
            time.sleep(0.2)
            self.set_color(0, base_brightness, base_brightness)
            time.sleep(0.3)

    def _sleepy_animation(self):
        """Very dim warm white, slowly pulsing"""
        while self.is_running and self.current_mode == 'sleepy':
            for brightness in range(0, 21, 1):
                if not self.is_running:
                    break
                # Warm white mix (more red, less blue)
                self.set_color(brightness, brightness-5, brightness-10)
                time.sleep(0.2)
            for brightness in range(20, -1, -1):
                if not self.is_running:
                    break
                self.set_color(brightness, brightness-5, brightness-10)
                time.sleep(0.2)

    def stop(self):
        """Stop LED operations"""
        self.is_running = False
        if self.animation_thread:
            self.animation_thread.join()

        # Turn off all LEDs
        self.set_color(0, 0, 0)

        # Clean up GPIO
        self.red_pwm.stop()
        self.green_pwm.stop()
        self.blue_pwm.stop()
        GPIO.cleanup([self.RED_PIN, self.GREEN_PIN, self.BLUE_PIN])