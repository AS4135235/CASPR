# Hardware package initialization
