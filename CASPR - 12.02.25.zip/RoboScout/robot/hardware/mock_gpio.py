"""Mock GPIO module for development and testing"""
import time

# GPIO mode constants
BCM = 11
BOARD = 10
OUT = 0
IN = 1
HIGH = 1
LOW = 0
PUD_UP = 22
PUD_DOWN = 21

_gpio_mode = None
_pin_states = {}
_pwm_instances = {}

def setmode(mode):
    """Set GPIO mode"""
    global _gpio_mode
    _gpio_mode = mode

def setup(channel, state, initial=LOW, pull_up_down=None):
    """Setup GPIO channel"""
    _pin_states[channel] = initial

def output(channel, state):
    """Set output state"""
    _pin_states[channel] = state

def input(channel):
    """Read input state"""
    return _pin_states.get(channel, 0)

def cleanup(pins=None):
    """Cleanup GPIO"""
    global _pin_states
    if pins is None:
        _pin_states = {}
    else:
        for pin in pins:
            _pin_states.pop(pin, None)

class PWM:
    """Mock PWM class"""
    def __init__(self, channel, frequency):
        self.channel = channel
        self.frequency = frequency
        self.duty_cycle = 0
        self.running = False
        _pwm_instances[channel] = self

    def start(self, duty_cycle):
        """Start PWM"""
        self.duty_cycle = duty_cycle
        self.running = True

    def stop(self):
        """Stop PWM"""
        self.running = False

    def ChangeDutyCycle(self, duty_cycle):
        """Change duty cycle"""
        self.duty_cycle = duty_cycle

    def ChangeFrequency(self, frequency):
        """Change frequency"""
        self.frequency = frequency

# Export the module name as GPIO for compatibility
GPIO = type('GPIO', (), {
    'setmode': setmode,
    'setup': setup,
    'output': output,
    'input': input,
    'cleanup': cleanup,
    'PWM': PWM,
    'BCM': BCM,
    'BOARD': BOARD,
    'OUT': OUT,
    'IN': IN,
    'HIGH': HIGH,
    'LOW': LOW,
    'PUD_UP': PUD_UP,
    'PUD_DOWN': PUD_DOWN,
})