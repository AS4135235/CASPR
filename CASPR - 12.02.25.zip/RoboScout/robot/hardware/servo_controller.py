import time
import threading
import os
import random

# Use mock GPIO for development, real GPIO on Raspberry Pi
try:
    import RPi.GPIO as GPIO
except ImportError:
    from .mock_gpio import GPIO

class ServoController:
    def __init__(self):
        # GPIO pins for head servos
        self.PAN_SERVO_PIN = 12
        self.TILT_SERVO_PIN = 13
        self.ROLL_SERVO_PIN = 16  # New pin for roll control
        # GPIO pins for eyelid servos
        self.LEFT_EYELID_PIN = 14
        self.RIGHT_EYELID_PIN = 15

        # Current positions (in degrees)
        self.current_pan = 90
        self.current_tilt = 90
        self.current_roll = 90  # Neutral position for roll
        self.left_eyelid = 90  # 90 is fully open, 0 is closed
        self.right_eyelid = 90

        # Movement limits
        self.PAN_LIMITS = (0, 180)
        self.TILT_LIMITS = (0, 180)
        self.ROLL_LIMITS = (60, 120)  # Limit roll to ±30 degrees from center
        self.EYELID_LIMITS = (0, 90)

        # PWM settings
        self.FREQUENCY = 50
        self.MIN_DUTY = 2.5
        self.MAX_DUTY = 12.5

        self.setup_gpio()
        self.is_tracking = False
        self.current_mood = 'normal'
        self.animation_thread = None
        self.is_running = True

    def setup_gpio(self):
        """Initialize GPIO for servo control"""
        GPIO.setmode(GPIO.BCM)

        # Setup all servo pins
        pins = [self.PAN_SERVO_PIN, self.TILT_SERVO_PIN, self.ROLL_SERVO_PIN,
                self.LEFT_EYELID_PIN, self.RIGHT_EYELID_PIN]

        for pin in pins:
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)

        # Initialize PWM for all servos
        self.pan_pwm = GPIO.PWM(self.PAN_SERVO_PIN, self.FREQUENCY)
        self.tilt_pwm = GPIO.PWM(self.TILT_SERVO_PIN, self.FREQUENCY)
        self.roll_pwm = GPIO.PWM(self.ROLL_SERVO_PIN, self.FREQUENCY)
        self.left_eyelid_pwm = GPIO.PWM(self.LEFT_EYELID_PIN, self.FREQUENCY)
        self.right_eyelid_pwm = GPIO.PWM(self.RIGHT_EYELID_PIN, self.FREQUENCY)

        # Start PWM with neutral positions
        self.pan_pwm.start(self._angle_to_duty_cycle(90))
        self.tilt_pwm.start(self._angle_to_duty_cycle(90))
        self.roll_pwm.start(self._angle_to_duty_cycle(90))
        self.left_eyelid_pwm.start(self._angle_to_duty_cycle(90))
        self.right_eyelid_pwm.start(self._angle_to_duty_cycle(90))

    def _angle_to_duty_cycle(self, angle):
        """Convert angle to duty cycle"""
        duty = self.MIN_DUTY + (angle / 180.0) * (self.MAX_DUTY - self.MIN_DUTY)
        return max(min(duty, self.MAX_DUTY), self.MIN_DUTY)

    def set_pan(self, angle):
        """Set pan servo angle"""
        angle = max(min(angle, self.PAN_LIMITS[1]), self.PAN_LIMITS[0])
        duty = self._angle_to_duty_cycle(angle)
        self.pan_pwm.ChangeDutyCycle(duty)
        self.current_pan = angle
        time.sleep(0.1)  # Allow servo to reach position

    def set_tilt(self, angle):
        """Set tilt servo angle"""
        angle = max(min(angle, self.TILT_LIMITS[1]), self.TILT_LIMITS[0])
        duty = self._angle_to_duty_cycle(angle)
        self.tilt_pwm.ChangeDutyCycle(duty)
        self.current_tilt = angle
        time.sleep(0.1)  # Allow servo to reach position

    def set_roll(self, angle):
        """Set roll servo angle"""
        angle = max(min(angle, self.ROLL_LIMITS[1]), self.ROLL_LIMITS[0])
        duty = self._angle_to_duty_cycle(angle)
        self.roll_pwm.ChangeDutyCycle(duty)
        self.current_roll = angle
        time.sleep(0.1)  # Allow servo to reach position

    def set_eyelids(self, left_angle, right_angle):
        """Set eyelid positions"""
        # Constrain angles to limits
        left_angle = max(min(left_angle, self.EYELID_LIMITS[1]), self.EYELID_LIMITS[0])
        right_angle = max(min(right_angle, self.EYELID_LIMITS[1]), self.EYELID_LIMITS[0])

        # Set positions
        self.left_eyelid_pwm.ChangeDutyCycle(self._angle_to_duty_cycle(left_angle))
        self.right_eyelid_pwm.ChangeDutyCycle(self._angle_to_duty_cycle(right_angle))
        self.left_eyelid = left_angle
        self.right_eyelid = right_angle
        time.sleep(0.1)

    def blink(self):
        """Perform a natural blinking motion"""
        current_left = self.left_eyelid
        current_right = self.right_eyelid

        # Close eyes quickly
        self.set_eyelids(0, 0)
        time.sleep(0.1)

        # Open eyes slightly slower
        self.set_eyelids(current_left, current_right)
        time.sleep(0.15)

    def set_head_position(self, pan, tilt, roll):
        """Set all head servos to specified angles"""
        self.set_pan(pan)
        self.set_tilt(tilt)
        self.set_roll(roll)

    def set_mood(self, mood):
        """Set the robot's mood, affecting head and eyelid movements"""
        self.current_mood = mood
        if self.animation_thread and self.animation_thread.is_alive():
            self.is_running = False
            self.animation_thread.join()

        self.is_running = True
        self.animation_thread = threading.Thread(target=self._mood_animation_loop)
        self.animation_thread.daemon = True
        self.animation_thread.start()

    def _mood_animation_loop(self):
        """Main loop for mood-based animations"""
        while self.is_running:
            if self.current_mood == 'happy':
                self._happy_movement()
            elif self.current_mood == 'curious':
                self._curious_movement()
            elif self.current_mood == 'sleepy':
                self._sleepy_movement()
            elif self.current_mood == 'excited':
                self._excited_movement()
            elif self.current_mood == 'suspicious':
                self._suspicious_movement()

            # Add random blinking
            if not self.current_mood == 'sleepy':
                if random.random() < 0.1:  # 10% chance each cycle
                    self.blink()

            time.sleep(0.1)

    def _happy_movement(self):
        """Happy mood movements - gentle, smooth motions with slight head tilts"""
        # Wider eyes for happy expression
        self.set_eyelids(90, 90)  # Fully open
        self.set_tilt(100)  # Slightly raised head
        time.sleep(1)
        # Gentle side-to-side movement with slight rolls
        for _ in range(2):  # Repeat the movement
            # Look left with slight right roll
            self.set_head_position(70, 100, 95)
            time.sleep(0.5)
            # Look right with slight left roll
            self.set_head_position(110, 100, 85)
            time.sleep(0.5)
        # Return to center
        self.set_head_position(90, 90, 90)

    def _curious_movement(self):
        """Curious mood movements - alert, investigative with head tilts"""
        # Wide eyes and tilted head
        self.set_eyelids(90, 90)  # Eyes wide open
        for _ in range(2):  # Repeat investigative pattern
            # Look up-left with slight right roll
            self.set_head_position(70, 110, 100)
            time.sleep(0.3)
            # Look down-right with slight left roll
            self.set_head_position(110, 70, 80)
            time.sleep(0.3)
        # Return to neutral
        self.set_head_position(90, 90, 90)

    def _sleepy_movement(self):
        """Sleepy mood movements - slow, heavy motions with drooping"""
        # Droopy eyelids
        self.set_eyelids(30, 30)
        # Lowered head with slight roll
        self.set_head_position(75, 70, 85)
        time.sleep(1)
        # Slow head movement
        self.set_head_position(85, 65, 95)
        time.sleep(1)
        # Occasional slow blink
        self.set_eyelids(10, 10)  # Almost closed
        time.sleep(0.5)
        self.set_eyelids(30, 30)  # Back to droopy
        time.sleep(0.5)

    def _excited_movement(self):
        """Excited mood movements - rapid, energetic with dynamic head rolls"""
        # Quick head movements with wide eyes
        self.set_eyelids(90, 90)  # Eyes wide open
        for _ in range(3):  # More energetic movements
            # Quick left with right roll
            self.set_head_position(60, 110, 105)
            time.sleep(0.2)
            # Quick right with left roll
            self.set_head_position(120, 90, 75)
            time.sleep(0.2)
            # Look up with neutral roll
            self.set_head_position(90, 110, 90)
            time.sleep(0.2)
        # Return to center
        self.set_head_position(90, 90, 90)

    def _suspicious_movement(self):
        """Suspicious mood movements - asymmetric, alert with questioning head tilts"""
        # Squinting eyes - slightly asymmetric
        self.set_eyelids(40, 35)  # Left eye slightly more open
        # Slow, calculated head movements
        # Look right with left roll (skeptical tilt)
        self.set_head_position(120, 100, 80)
        time.sleep(0.8)
        # Look left with right roll
        self.set_head_position(60, 100, 100)
        time.sleep(0.8)
        self.set_eyelids(35, 40)  # Switch eye pattern
        time.sleep(0.5)
        # Return to neutral but maintain suspicious eyes
        self.set_head_position(90, 90, 90)
        self.set_eyelids(45, 45)  # Both eyes slightly squinting

    def stop(self):
        """Stop all servo operations"""
        self.is_running = False
        if self.animation_thread:
            self.animation_thread.join()

        # Center everything
        self.set_head_position(90, 90, 90)
        self.set_eyelids(90, 90)

        # Clean up
        self.pan_pwm.stop()
        self.tilt_pwm.stop()
        self.roll_pwm.stop()
        self.left_eyelid_pwm.stop()
        self.right_eyelid_pwm.stop()
        GPIO.cleanup([self.PAN_SERVO_PIN, self.TILT_SERVO_PIN, self.ROLL_SERVO_PIN,
                     self.LEFT_EYELID_PIN, self.RIGHT_EYELID_PIN])