import scapy.all as scapy
from scapy.layers import http
import threading
import time
from datetime import datetime
import warnings

class NetworkMonitor:
    def __init__(self):
        self.is_running = False
        self.network_data = {}
        self.known_devices = set()
        self.suspicious_activity = []
        self.lock = threading.Lock()
        self.bluetooth_available = False
        self.wifi_monitoring_enabled = False

        # Try to import bluetooth module
        try:
            import bluetooth
            self.bluetooth = bluetooth
            self.bluetooth_available = True
        except ImportError:
            warnings.warn("Bluetooth module not available. Bluetooth monitoring disabled.")
            self.bluetooth = None

        # Check if we have permission for network monitoring
        try:
            # Try to capture a single packet to test permissions
            scapy.sniff(count=1, timeout=1)
            self.wifi_monitoring_enabled = True
        except Exception as e:
            if 'Operation not permitted' in str(e):
                warnings.warn("Insufficient permissions for WiFi monitoring. Run with elevated privileges to enable this feature.")
            else:
                warnings.warn(f"WiFi monitoring disabled: {str(e)}")

    def start_monitoring(self):
        """Start network monitoring threads"""
        self.is_running = True

        # Start monitoring threads
        threads = []

        # Only add WiFi monitoring if we have permissions
        if self.wifi_monitoring_enabled:
            threads.append(threading.Thread(target=self._monitor_wifi))
            threads.append(threading.Thread(target=self._analyze_traffic))

        # Only add bluetooth monitoring if available
        if self.bluetooth_available:
            threads.append(threading.Thread(target=self._monitor_bluetooth))

        for thread in threads:
            thread.daemon = True
            thread.start()

    def stop(self):
        """Stop network monitoring"""
        self.is_running = False

    def _monitor_wifi(self):
        """Monitor WiFi network traffic"""
        while self.is_running:
            try:
                # Capture network packets
                packets = scapy.sniff(count=10, timeout=2)

                with self.lock:
                    for packet in packets:
                        if packet.haslayer(scapy.IP):
                            src_ip = packet[scapy.IP].src
                            dst_ip = packet[scapy.IP].dst

                            # Record traffic data
                            if src_ip not in self.network_data:
                                self.network_data[src_ip] = {
                                    'packets_sent': 0,
                                    'packets_received': 0,
                                    'first_seen': datetime.now(),
                                    'last_seen': datetime.now()
                                }

                            self.network_data[src_ip]['packets_sent'] += 1
                            self.network_data[src_ip]['last_seen'] = datetime.now()

                            # Check for suspicious patterns
                            self._check_suspicious_activity(src_ip, dst_ip, packet)

            except Exception as e:
                if 'Operation not permitted' not in str(e):  # Don't spam logs with permission errors
                    warnings.warn(f"Error monitoring WiFi: {str(e)}")
                time.sleep(1)

    def _monitor_bluetooth(self):
        """Monitor Bluetooth devices if available"""
        if not self.bluetooth_available:
            return

        while self.is_running:
            try:
                nearby_devices = self.bluetooth.discover_devices(
                    duration=8,
                    lookup_names=True,
                    flush_cache=True,
                    lookup_class=True
                )

                current_devices = set()
                for addr, name, device_class in nearby_devices:
                    current_devices.add(addr)

                    if addr not in self.known_devices:
                        with self.lock:
                            self.suspicious_activity.append({
                                'timestamp': datetime.now(),
                                'type': 'new_bluetooth_device',
                                'details': f"New Bluetooth device detected: {name} ({addr})"
                            })

                self.known_devices.update(current_devices)
                time.sleep(10)

            except Exception as e:
                warnings.warn(f"Error monitoring Bluetooth: {str(e)}")
                time.sleep(5)

    def _analyze_traffic(self):
        """Analyze network traffic patterns"""
        while self.is_running and self.wifi_monitoring_enabled:
            try:
                with self.lock:
                    current_time = datetime.now()

                    # Check for unusual traffic patterns
                    for ip, data in self.network_data.items():
                        # Check for high traffic volume
                        if data['packets_sent'] > 1000:  # Threshold
                            self.suspicious_activity.append({
                                'timestamp': current_time,
                                'type': 'high_traffic',
                                'details': f"High traffic volume from {ip}"
                            })

                        # Check for potential port scanning
                        if len(data.get('ports_accessed', [])) > 20:  # Threshold
                            self.suspicious_activity.append({
                                'timestamp': current_time,
                                'type': 'port_scanning',
                                'details': f"Possible port scanning from {ip}"
                            })

                time.sleep(5)

            except Exception as e:
                warnings.warn(f"Error analyzing traffic: {str(e)}")
                time.sleep(1)

    def _check_suspicious_activity(self, src_ip, dst_ip, packet):
        """Check for suspicious network activity"""
        try:
            # Check for common attack patterns
            if packet.haslayer(scapy.TCP):
                # SYN flood detection
                if packet[scapy.TCP].flags == 2:  # SYN flag
                    if src_ip in self.network_data:
                        syn_count = self.network_data[src_ip].get('syn_count', 0) + 1
                        self.network_data[src_ip]['syn_count'] = syn_count

                        if syn_count > 100:  # Threshold
                            self.suspicious_activity.append({
                                'timestamp': datetime.now(),
                                'type': 'syn_flood',
                                'details': f"Possible SYN flood attack from {src_ip}"
                            })

            # Check for HTTP attacks
            if packet.haslayer(http.HTTPRequest):
                http_layer = packet.getlayer(http.HTTPRequest)
                path = http_layer.fields.get('Path', b'').decode('utf-8', 'ignore')
                if '../' in path:
                    self.suspicious_activity.append({
                        'timestamp': datetime.now(),
                        'type': 'path_traversal',
                        'details': f"Possible path traversal attack from {src_ip}"
                    })

        except Exception as e:
            warnings.warn(f"Error checking suspicious activity: {str(e)}")

    def get_latest_data(self):
        """Get the latest network monitoring data"""
        with self.lock:
            return {
                'network_data': self.network_data,
                'suspicious_activity': self.suspicious_activity[-10:],  # Last 10 events
                'known_bluetooth_devices': list(self.known_devices) if self.bluetooth_available else [],
                'bluetooth_monitoring': 'enabled' if self.bluetooth_available else 'disabled',
                'wifi_monitoring': 'enabled' if self.wifi_monitoring_enabled else 'disabled'
            }