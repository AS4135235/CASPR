import hashlib
import time
import jwt
from datetime import datetime, timedelta

class AuthenticationSystem:
    def __init__(self):
        self.SECRET_KEY = "your-secret-key"  # In production, use secure key storage
        self.authorized_users = {}  # Store user credentials
        self.voice_patterns = {}    # Store voice signatures
        self.session_tokens = {}    # Store active sessions
        
    def register_user(self, username, password, voice_pattern=None):
        """Register a new user"""
        if username in self.authorized_users:
            return False, "Username already exists"
            
        # Hash password
        salt = hashlib.sha256(str(time.time()).encode()).hexdigest()[:6]
        hashed_password = self._hash_password(password, salt)
        
        self.authorized_users[username] = {
            'password': hashed_password,
            'salt': salt,
            'created_at': datetime.now(),
            'permissions': ['basic']
        }
        
        if voice_pattern:
            self.voice_patterns[username] = voice_pattern
            
        return True, "User registered successfully"

    def authenticate_user(self, username, password):
        """Authenticate user with username and password"""
        if username not in self.authorized_users:
            return False, "User not found"
            
        user = self.authorized_users[username]
        hashed_input = self._hash_password(password, user['salt'])
        
        if hashed_input == user['password']:
            token = self._generate_token(username)
            self.session_tokens[username] = token
            return True, token
        
        return False, "Invalid credentials"

    def verify_voice(self, username, voice_pattern, threshold=0.8):
        """Verify user's voice pattern"""
        if username not in self.voice_patterns:
            return False, "No voice pattern registered"
            
        stored_pattern = self.voice_patterns[username]
        similarity = self._compare_voice_patterns(voice_pattern, stored_pattern)
        
        if similarity >= threshold:
            return True, "Voice verified"
        
        return False, "Voice verification failed"

    def verify_token(self, token):
        """Verify JWT token"""
        try:
            payload = jwt.decode(token, self.SECRET_KEY, algorithms=["HS256"])
            username = payload.get('username')
            
            if username in self.session_tokens and \
               self.session_tokens[username] == token:
                return True, username
                
            return False, "Invalid token"
            
        except jwt.ExpiredSignatureError:
            return False, "Token expired"
        except jwt.InvalidTokenError:
            return False, "Invalid token"

    def _hash_password(self, password, salt):
        """Hash password with salt"""
        return hashlib.sha256(
            f"{password}{salt}".encode()
        ).hexdigest()

    def _generate_token(self, username):
        """Generate JWT token"""
        payload = {
            'username': username,
            'exp': datetime.utcnow() + timedelta(hours=24),
            'iat': datetime.utcnow()
        }
        return jwt.encode(payload, self.SECRET_KEY, algorithm="HS256")

    def _compare_voice_patterns(self, pattern1, pattern2):
        """Compare two voice patterns and return similarity score"""
        try:
            # Implement voice pattern comparison logic
            # This is a simplified example - real implementation would be more complex
            features = ['pitch', 'energy', 'frequency_distribution']
            similarities = []
            
            for feature in features:
                if feature in pattern1 and feature in pattern2:
                    diff = abs(pattern1[feature] - pattern2[feature])
                    max_val = max(pattern1[feature], pattern2[feature])
                    similarity = 1 - (diff / max_val if max_val != 0 else 0)
                    similarities.append(similarity)
            
            return sum(similarities) / len(similarities) if similarities else 0
            
        except Exception as e:
            print(f"Error comparing voice patterns: {e}")
            return 0

    def revoke_token(self, username):
        """Revoke user's active session token"""
        if username in self.session_tokens:
            del self.session_tokens[username]
            return True
        return False

    def add_permission(self, username, permission):
        """Add permission to user"""
        if username in self.authorized_users:
            if 'permissions' not in self.authorized_users[username]:
                self.authorized_users[username]['permissions'] = []
            self.authorized_users[username]['permissions'].append(permission)
            return True
        return False

    def check_permission(self, username, permission):
        """Check if user has specific permission"""
        if username in self.authorized_users:
            return permission in self.authorized_users[username].get('permissions', [])
        return False

